package app.glasstube

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

private const val HOME = "https://m.youtube.com/"
private const val LOGIN = "https://accounts.google.com/ServiceLogin?service=youtube&hl=pl&continue=https%3A%2F%2Fm.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Dm%26next%3D%252F"
private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
private val BG = Color.rgb(15, 15, 15)
private val ALLOWED = Regex("(^|\\.)(youtube\\.com|youtu\\.be|google\\.[a-z.]+|gstatic\\.com|googleusercontent\\.com|googlevideo\\.com)$")

// Chowa dolny pasek YouTube (zastępuje go szklany pasek aplikacji) i baner "zainstaluj aplikację".
private const val CSS = "(function(){var s=document.getElementById('gt');if(!s&&document.head){s=document.createElement('style');s.id='gt';document.head.appendChild(s)}if(s)s.textContent='ytm-pivot-bar-renderer,ytm-mealbar-promo-renderer{display:none!important}'})()"

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var prog: View
    private lateinit var pill: LinearLayout
    private val tabs = ArrayList<LinearLayout>()
    private var login: View? = null
    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var oldUi = 0
    private var want = false
    private var shown = true
    private var sel = -1

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        else window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        val ck = CookieManager.getInstance()
        ck.setAcceptCookie(true)
        // ciemny motyw YouTube, tylko gdy użytkownik nie ma jeszcze własnych ustawień
        if (ck.getCookie("https://m.youtube.com")?.contains("PREF=") != true)
            ck.setCookie("https://m.youtube.com", "PREF=f6=400&hl=pl; Domain=.youtube.com; Path=/; Secure; Max-Age=31536000")

        web = WebView(this).apply {
            setBackgroundColor(BG)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                // bez "wv", inaczej Google blokuje logowanie w osadzonym WebView
                userAgentString = userAgentString.replace("; wv", "").replace(" Version/4.0", "")
            }
            setOnScrollChangeListener { _, _, y, _, oy ->
                if (y - oy > 12) showPill(false) else if (y - oy < -12) showPill(true)
            }
        }
        ck.setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                if (r == null || !r.isForMainFrame) return false
                val u = r.url
                if (u.scheme != "http" && u.scheme != "https") return true
                if (ALLOWED.containsMatchIn(u.host ?: "")) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                return true
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) = chrome(url)

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                view?.evaluateJavascript(CSS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(CSS, null)
                chrome(url)
                CookieManager.getInstance().flush()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, p: Int) {
                prog.scaleX = p / 100f
                prog.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View?, cb: WebChromeClient.CustomViewCallback?) = enterFs(view, cb)
            override fun onHideCustomView() = exitFs()
            override fun getDefaultVideoPoster(): Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }

        prog = View(this).apply {
            setBackgroundColor(Color.rgb(255, 45, 85))
            pivotX = 0f
            scaleX = 0f
            visibility = View.GONE
        }
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        root.addView(web, FrameLayout.LayoutParams(MP, MP))
        root.addView(prog, FrameLayout.LayoutParams(MP, dp(3)))
        buildPill()
        root.setOnApplyWindowInsetsListener { _, i ->
            val top = i.systemWindowInsetTop
            val bot = i.systemWindowInsetBottom
            (web.layoutParams as FrameLayout.LayoutParams).setMargins(0, top, 0, bot)
            (prog.layoutParams as FrameLayout.LayoutParams).topMargin = top
            (pill.layoutParams as FrameLayout.LayoutParams).bottomMargin = bot + dp(14)
            web.requestLayout(); prog.requestLayout(); pill.requestLayout()
            i
        }
        setContentView(root)

        if (loggedIn() || getSharedPreferences("g", MODE_PRIVATE).getBoolean("skip", false)) web.loadUrl(HOME)
        else showLogin()
    }

    private fun loggedIn(): Boolean {
        val c = CookieManager.getInstance().getCookie("https://www.youtube.com") ?: return false
        return c.contains("SAPISID=") || c.contains("__Secure-3PSID=")
    }

    // ---------- szklany pasek ----------
    private fun buildPill() {
        val icons = intArrayOf(R.drawable.ic_home, R.drawable.ic_shorts, R.drawable.ic_subs, R.drawable.ic_lib)
        val names = arrayOf("Start", "Shorts", "Subskrypcje", "Biblioteka")
        val urls = arrayOf(HOME, HOME + "shorts", HOME + "feed/subscriptions", HOME + "feed/library")
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GlassDrawable(999f, dpf(1.2f), Color.argb(120, 12, 12, 18))
            visibility = View.GONE
        }
        for (i in icons.indices) {
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { web.loadUrl(urls[i]) }
            }
            t.addView(ImageView(this).apply { setImageResource(icons[i]) }, LinearLayout.LayoutParams(dp(24), dp(24)))
            t.addView(TextView(this).apply {
                text = names[i]
                textSize = 10f
                setSingleLine()
                setPadding(0, dp(2), 0, 0)
            }, LinearLayout.LayoutParams(WC, WC))
            pill.addView(t, LinearLayout.LayoutParams(dp(72), dp(52)).apply { setMargins(dp(2), 0, dp(2), 0) })
            tabs.add(t)
        }
        root.addView(pill, FrameLayout.LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        paint()
    }

    private fun paint() {
        tabs.forEachIndexed { i, t ->
            val on = i == sel
            val c = if (on) Color.WHITE else white(150)
            t.background = if (on) GlassDrawable(999f, dpf(1f), white(36)) else null
            (t.getChildAt(0) as ImageView).imageTintList = ColorStateList.valueOf(c)
            (t.getChildAt(1) as TextView).apply {
                setTextColor(c)
                typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }
    }

    private fun setWant(w: Boolean) {
        want = w
        pill.visibility = if (w) View.VISIBLE else View.GONE
        if (w) { pill.translationY = 0f; pill.alpha = 1f; shown = true }
    }

    private fun showPill(s: Boolean) {
        if (!want || s == shown) return
        shown = s
        pill.animate().translationY(if (s) 0f else (pill.height + dp(40)).toFloat())
            .alpha(if (s) 1f else 0f).setDuration(220).start()
    }

    /** Pasek widoczny tylko na YouTube i nie na /watch ani w Shorts; zaznacza aktywną zakładkę. */
    private fun chrome(url: String?) {
        val u = Uri.parse(url ?: return)
        val p = u.path ?: "/"
        setWant((u.host ?: "").endsWith("youtube.com") && !p.startsWith("/watch") && !p.startsWith("/shorts/"))
        sel = when {
            p == "/" || p.isEmpty() -> 0
            p.startsWith("/shorts") -> 1
            p.startsWith("/feed/subscriptions") -> 2
            p.startsWith("/feed/library") || p.startsWith("/feed/you") -> 3
            else -> -1
        }
        paint()
    }

    // ---------- logowanie ----------
    private fun txt(s: String, sp: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(c)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun closeLogin() {
        login?.let { root.removeView(it) }
        login = null
    }

    private fun showLogin() {
        val f = FrameLayout(this)
        f.addView(MeshView(this), FrameLayout.LayoutParams(MP, MP))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(26), dp(32), dp(26), dp(22))
            background = GlassDrawable(dpf(32f), dpf(1.2f), Color.argb(70, 10, 10, 16))
        }
        card.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(72), dp(72)))
        card.addView(txt("GlassTube", 30f, Color.WHITE, true), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(16) })
        card.addView(txt("YouTube w szklanym wydaniu", 14f, white(170)), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(4) })
        card.addView(txt("Zaloguj się przez Google", 16f, Color.WHITE, true).apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GlassDrawable(999f, dpf(1.2f), Color.argb(215, 255, 45, 85))
            setOnClickListener { closeLogin(); web.loadUrl(LOGIN) }
        }, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(32) })
        card.addView(txt("Kontynuuj bez logowania", 14f, white(150)).apply {
            setPadding(dp(12), dp(14), dp(12), dp(6))
            setOnClickListener {
                getSharedPreferences("g", MODE_PRIVATE).edit().putBoolean("skip", true).apply()
                closeLogin()
                web.loadUrl(HOME)
            }
        }, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(8) })
        f.addView(card, FrameLayout.LayoutParams(minOf(resources.displayMetrics.widthPixels - dp(48), dp(380)), WC, Gravity.CENTER))
        root.addView(f, FrameLayout.LayoutParams(MP, MP))
        login = f
    }

    // ---------- pełny ekran wideo ----------
    private fun enterFs(v: View?, cb: WebChromeClient.CustomViewCallback?) {
        if (v == null) return
        if (custom != null) { cb?.onCustomViewHidden(); return }
        custom = v
        customCb = cb
        v.setBackgroundColor(Color.BLACK)
        val d = window.decorView
        oldUi = d.systemUiVisibility
        (d as FrameLayout).addView(v, FrameLayout.LayoutParams(MP, MP))
        d.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        if (Build.VERSION.SDK_INT >= 28) window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun exitFs() {
        val v = custom ?: return
        custom = null
        (window.decorView as FrameLayout).removeView(v)
        customCb?.onCustomViewHidden()
        customCb = null
        window.decorView.systemUiVisibility = oldUi
        if (Build.VERSION.SDK_INT >= 28) window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            custom != null -> exitFs()
            login == null && web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { web.onPause(); CookieManager.getInstance().flush(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
