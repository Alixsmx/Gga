package app.glasstube

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

fun white(a: Int) = Color.argb(a, 255, 255, 255)

/** Szkło: ciemna baza + połysk z góry + świetlista krawędź (gradientowy rim). */
class GlassDrawable(private val r: Float, private val sw: Float, private val tint: Int) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var wash: Shader? = null
    private var rim: Shader? = null

    override fun onBoundsChange(b: Rect) {
        rect.set(b)
        rect.inset(sw / 2, sw / 2)
        wash = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), white(64), white(8), Shader.TileMode.CLAMP)
        rim = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(white(200), white(24), white(96)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = tint
        c.drawRoundRect(rect, r, r, p)
        p.color = Color.WHITE
        p.shader = wash
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.shader = rim
        c.drawRoundRect(rect, r, r, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Powoli płynące, kolorowe plamy za szklaną kartą logowania. */
class MeshView(c: Context) : View(c) {
    private val p = Paint()
    private val cols = intArrayOf(Color.argb(150, 255, 45, 85), Color.argb(140, 120, 70, 255), Color.argb(130, 40, 110, 255))
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 6.2831855f).apply {
        duration = 22000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.rgb(7, 7, 12))
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in cols.indices) {
            val a = t + i * 2.1f
            val x = w * (0.25f + 0.25f * i) + sin(a) * w * 0.12f
            val y = h * (0.2f + 0.3f * i) + cos(a * 0.8f) * h * 0.08f
            p.shader = RadialGradient(x, y, maxOf(w, h) * 0.6f, cols[i], cols[i] and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
        }
    }
}
